
#' Predict computation time for exact power
#' 
#' Computation time depends on sample size through the product.
#' Based on a set of experiments on the author's desktop the
#' function returns the predicted computation time in seconds.
#' 
#'
#' @param n0 control sample size
#' @param n1 treatment sample size
#' @return integer
#' @author Chris J. Lloyd
#' @examples
#' forecast.time(50,60)
#' @export forecast.time

forecast.time=function(n0,n1){
  round(exp(-13.16)*(n0*n1)^(1.711),0)
  }